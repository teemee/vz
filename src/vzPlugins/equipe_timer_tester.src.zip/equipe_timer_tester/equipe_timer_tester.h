// equipe_timer_tester.h : main header file for the EQUIPE_TIMER_TESTER application
//

#if !defined(AFX_EQUIPE_TIMER_TESTER_H__ABCF9D8B_C10C_419E_8D74_7D9C04350B74__INCLUDED_)
#define AFX_EQUIPE_TIMER_TESTER_H__ABCF9D8B_C10C_419E_8D74_7D9C04350B74__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CEquipe_timer_testerApp:
// See equipe_timer_tester.cpp for the implementation of this class
//

class CEquipe_timer_testerApp : public CWinApp
{
public:
	CEquipe_timer_testerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEquipe_timer_testerApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CEquipe_timer_testerApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EQUIPE_TIMER_TESTER_H__ABCF9D8B_C10C_419E_8D74_7D9C04350B74__INCLUDED_)
