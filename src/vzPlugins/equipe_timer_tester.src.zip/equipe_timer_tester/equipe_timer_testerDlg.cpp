// equipe_timer_testerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "equipe_timer_tester.h"
#include "equipe_timer_testerDlg.h"

#include <Mmsystem.h>
#pragma comment(lib, "winmm.lib")

#include <afxpriv.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define MAX_TIMERS 4
#define EQUIPE_CMD_LEN 6

struct timers_description
{
	long enabled;
	long value;
	long running;
	long countdown;
	long start;
	long last;
	long data;
};

static struct timers_description timers[MAX_TIMERS];
static long timers_writer_exit = 0;
static HANDLE timers_writer = INVALID_HANDLE_VALUE;
static HANDLE timers_lock = INVALID_HANDLE_VALUE;
static int id_groups[4][9] = 
{
	{IDC_CURRENT_1,IDC_EDIT_START_1,IDC_RADIO_UP_1,IDC_RADIO_DOWN_1,IDC_B_START_1,IDC_B_STOP_1,IDC_B_CONT_1,IDC_B_RESET_1, IDC_ENABLE_1},
	{IDC_CURRENT_2,IDC_EDIT_START_2,IDC_RADIO_UP_2,IDC_RADIO_DOWN_2,IDC_B_START_2,IDC_B_STOP_2,IDC_B_CONT_2,IDC_B_RESET_2, IDC_ENABLE_2},
	{IDC_CURRENT_3,IDC_EDIT_START_3,IDC_RADIO_UP_3,IDC_RADIO_DOWN_3,IDC_B_START_3,IDC_B_STOP_3,IDC_B_CONT_3,IDC_B_RESET_3, IDC_ENABLE_3},
	{IDC_CURRENT_4,IDC_EDIT_START_4,IDC_RADIO_UP_4,IDC_RADIO_DOWN_4,IDC_B_START_4,IDC_B_STOP_4,IDC_B_CONT_4,IDC_B_RESET_4, IDC_ENABLE_4}
};
static int find_group_id(int id)
{
	for(int j=0; j<4; j++)
		for(int i =0 ;i < 9; i++)
			if (id == id_groups[j][i] )
				return j;
	return -1;
}

static unsigned long WINAPI timers_writer_proc(void* data)
{
	timeBeginPeriod(1);

	CEquipe_timer_testerDlg* dlg = (CEquipe_timer_testerDlg*)data;
	char* serial_port_name = dlg->serial_port_name;

	/* open port */
	HANDLE com_port = CreateFile
	(
		serial_port_name,
		GENERIC_READ | GENERIC_WRITE,
		0,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL
	);

	/* check port opens */
	if (com_port == INVALID_HANDLE_VALUE)
	{
		fprintf(stderr, "ERROR opening port '%s'\n", serial_port_name);
		return 0;
	};

	/* configure */
	DCB lpdcb;
	memset(&lpdcb, 0, sizeof(DCB));
	lpdcb.BaudRate = (UINT) CBR_38400;		// 38400 b/s
											// a. 1 start bit ( space )
	lpdcb.ByteSize = (BYTE) 8;				// b. 8 data bits
	lpdcb.Parity = (BYTE) ODDPARITY;		// c. 1 parity bit (odd)
	lpdcb.StopBits = (BYTE) ONESTOPBIT;		// d. 1 stop bit (mark)
	lpdcb.fParity = 1;
	lpdcb.fBinary = 1;
	if (!(SetCommState(com_port, &lpdcb)))
	{
		fprintf(stderr, "ERROR configuring port '%s'\n", serial_port_name);
		CloseHandle(com_port);
		return 0;
	};

	/* ignore events from port like break... */
	SetCommMask(com_port, 0);

	/* endless loop */
	PurgeComm(com_port, PURGE_RXABORT | PURGE_RXCLEAR | PURGE_TXABORT | PURGE_TXCLEAR);

	while(!(timers_writer_exit))
	{
		int c = 0;

		// do job for all timers
		for(int i = 0 ; i < MAX_TIMERS ; i++)
		{
			/* lock timers data */
			WaitForSingleObject(timers_lock, INFINITE);

			/* check if timer is active */
			if(timers[i].enabled)
			{
				/* check if running */
				if(timers[i].running)
				{
					/* increment or descrement timer */
					long t = timeGetTime();
					if(timers[i].countdown)
					{
						/* decrement value */
						timers[i].value += (t - timers[i].last);

						/* calc data */
						timers[i].data = timers[i].start - timers[i].value;

						/* check if reached end of countdown timer */
						if (timers[i].data < 0)
						{
							timers[i].data = 0;
							timers[i].running = 0;
						};
					}
					else
					{
						/* increment value */
						timers[i].value += (t - timers[i].last);

						/* calc data */
						timers[i].data = timers[i].start + timers[i].value;
					};
				
					/* sync last value */
					timers[i].last = t;
				};

				/* compose command */
				unsigned char cmd_buffer[EQUIPE_CMD_LEN];

				/* compose header */
				cmd_buffer[0] = 0x50;
				if (timers[i].running) cmd_buffer[0] |= (1<<3);
				if (timers[i].countdown)  cmd_buffer[0] |= (1<<2);
				cmd_buffer[0] |= i;
				
				/* set value */
				*((long*)(&cmd_buffer[1])) = timers[i].data;
				
				/* calc checksum */
				cmd_buffer[EQUIPE_CMD_LEN - 1] = 0;
				for(int j=0;j<(EQUIPE_CMD_LEN - 1); j++) cmd_buffer[EQUIPE_CMD_LEN - 1] += cmd_buffer[j];

				/* release mutex */
				ReleaseMutex(timers_lock);

				/* send data to serial port */
				unsigned long wrote_len;
				WriteFile(com_port, &cmd_buffer, EQUIPE_CMD_LEN, &wrote_len, NULL);
				FlushFileBuffers(com_port);
			}
			else
				/* release mutex */
				ReleaseMutex(timers_lock);
		};

		/* check if sent at least one item */
		if(!(c))
			Sleep(0);
	};

	timeEndPeriod(1);
	CloseHandle(com_port);
	return 0;
}


/////////////////////////////////////////////////////////////////////////////
// CEquipe_timer_testerDlg dialog

CEquipe_timer_testerDlg::CEquipe_timer_testerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEquipe_timer_testerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEquipe_timer_testerDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CEquipe_timer_testerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEquipe_timer_testerDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CEquipe_timer_testerDlg, CDialog)
	//{{AFX_MSG_MAP(CEquipe_timer_testerDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DESTROY()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_KICKIDLE, OnKickIdle)

	ON_COMMAND_EX(IDC_ENABLE_1, TimerEnableDisable)
	ON_COMMAND_EX(IDC_ENABLE_2, TimerEnableDisable)
	ON_COMMAND_EX(IDC_ENABLE_3, TimerEnableDisable)
	ON_COMMAND_EX(IDC_ENABLE_4, TimerEnableDisable)
	// #1 commands
	ON_COMMAND_EX(IDC_RADIO_UP_1,	CommandsProcess)
	ON_COMMAND_EX(IDC_RADIO_DOWN_1,	CommandsProcess)
	ON_COMMAND_EX(IDC_B_START_1,	CommandsProcess)
	ON_COMMAND_EX(IDC_B_STOP_1,		CommandsProcess)
	ON_COMMAND_EX(IDC_B_CONT_1,		CommandsProcess)
	ON_COMMAND_EX(IDC_B_RESET_1,	CommandsProcess)
	// #2 commands
	ON_COMMAND_EX(IDC_RADIO_UP_2,	CommandsProcess)
	ON_COMMAND_EX(IDC_RADIO_DOWN_2,	CommandsProcess)
	ON_COMMAND_EX(IDC_B_START_2,	CommandsProcess)
	ON_COMMAND_EX(IDC_B_STOP_2,		CommandsProcess)
	ON_COMMAND_EX(IDC_B_CONT_2,		CommandsProcess)
	ON_COMMAND_EX(IDC_B_RESET_2,	CommandsProcess)
	// #3 commands
	ON_COMMAND_EX(IDC_RADIO_UP_3,	CommandsProcess)
	ON_COMMAND_EX(IDC_RADIO_DOWN_3,	CommandsProcess)
	ON_COMMAND_EX(IDC_B_START_3,	CommandsProcess)
	ON_COMMAND_EX(IDC_B_STOP_3,		CommandsProcess)
	ON_COMMAND_EX(IDC_B_CONT_3,		CommandsProcess)
	ON_COMMAND_EX(IDC_B_RESET_3,	CommandsProcess)
	// #4 commands
	ON_COMMAND_EX(IDC_RADIO_UP_4,	CommandsProcess)
	ON_COMMAND_EX(IDC_RADIO_DOWN_4,	CommandsProcess)
	ON_COMMAND_EX(IDC_B_START_4,	CommandsProcess)
	ON_COMMAND_EX(IDC_B_STOP_4,		CommandsProcess)
	ON_COMMAND_EX(IDC_B_CONT_4,		CommandsProcess)
	ON_COMMAND_EX(IDC_B_RESET_4,	CommandsProcess)

	// #1
	ON_UPDATE_COMMAND_UI(IDC_CURRENT_1,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_EDIT_START_1,	ui_update)
	ON_UPDATE_COMMAND_UI(IDC_RADIO_UP_1,	ui_update)
	ON_UPDATE_COMMAND_UI(IDC_RADIO_DOWN_1,	ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_START_1,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_STOP_1,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_CONT_1,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_RESET_1,		ui_update)
	// #2
	ON_UPDATE_COMMAND_UI(IDC_CURRENT_2,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_EDIT_START_2,	ui_update)
	ON_UPDATE_COMMAND_UI(IDC_RADIO_UP_2,	ui_update)
	ON_UPDATE_COMMAND_UI(IDC_RADIO_DOWN_2,	ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_START_2,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_STOP_2,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_CONT_2,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_RESET_2,		ui_update)
	// #3
	ON_UPDATE_COMMAND_UI(IDC_CURRENT_3,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_EDIT_START_3,	ui_update)
	ON_UPDATE_COMMAND_UI(IDC_RADIO_UP_3,	ui_update)
	ON_UPDATE_COMMAND_UI(IDC_RADIO_DOWN_3,	ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_START_3,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_STOP_3,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_CONT_3,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_RESET_3,		ui_update)
	// #4
	ON_UPDATE_COMMAND_UI(IDC_CURRENT_4,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_EDIT_START_4,	ui_update)
	ON_UPDATE_COMMAND_UI(IDC_RADIO_UP_4,	ui_update)
	ON_UPDATE_COMMAND_UI(IDC_RADIO_DOWN_4,	ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_START_4,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_STOP_4,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_CONT_4,		ui_update)
	ON_UPDATE_COMMAND_UI(IDC_B_RESET_4,		ui_update)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEquipe_timer_testerDlg message handlers

void CEquipe_timer_testerDlg::OnDestroy() 
{
	CDialog::OnDestroy();

	/* rise exit flag */
	timers_writer_exit = 1;

	/* wait for 'timers_reader_proc' finish */
	WaitForSingleObject(timers_writer, INFINITE);
	CloseHandle(timers_writer);

	// close mutex
	CloseHandle(timers_lock);
}


BOOL CEquipe_timer_testerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	/* init timers */
	timers_lock = CreateMutex(NULL,FALSE,NULL);
	memset(&timers, 0 , MAX_TIMERS * sizeof(struct timers_description));

	/* find command line arg */
	serial_port_name = "COM1:";
	if (__argc > 1) serial_port_name = __argv[1];

	/* start timer thread */
	unsigned long thread;
	timers_writer = CreateThread(0, 0, timers_writer_proc, this /* serial_port_name */, 0, &thread);
	
	SetTimer(0,0,NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEquipe_timer_testerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEquipe_timer_testerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CEquipe_timer_testerDlg::CommandsProcess(int id) 
{
	int gr, t_id;
	char temp_str[1024];

	/* check id present */
	if ( (-1) == (gr = find_group_id(id)) ) return FALSE;

	WaitForSingleObject(timers_lock, INFINITE);

	switch (id)
	{
		case IDC_B_RESET_1:
		case IDC_B_RESET_2:
		case IDC_B_RESET_3:
		case IDC_B_RESET_4:
			memset(&timers[gr], 0, sizeof(struct timers_description));
			timers[gr].enabled = 1;
			break;

		case IDC_B_CONT_1:
		case IDC_B_CONT_2:
		case IDC_B_CONT_3:
		case IDC_B_CONT_4:
			timers[gr].last = timeGetTime();
			timers[gr].running = 1;
			break;

		case IDC_RADIO_UP_1:
		case IDC_RADIO_UP_2:
		case IDC_RADIO_UP_3:
		case IDC_RADIO_UP_4:
			timers[gr].countdown = 0;
			break;

		case IDC_RADIO_DOWN_1:
		case IDC_RADIO_DOWN_3:
		case IDC_RADIO_DOWN_2:
		case IDC_RADIO_DOWN_4:
			timers[gr].countdown = 1;
			break;

//		case IDC_EDIT_START_1:
//		case IDC_EDIT_START_2:
//		case IDC_EDIT_START_3:
//		case IDC_EDIT_START_4:
		case IDC_B_START_1:
		case IDC_B_START_2:
		case IDC_B_START_3:
		case IDC_B_START_4:
			timers[gr].last = timeGetTime();
			timers[gr].running = 1;
			timers[gr].value = 0;
			switch(id)
			{
				case IDC_B_START_1: t_id = IDC_EDIT_START_1; break;
				case IDC_B_START_2: t_id = IDC_EDIT_START_2; break;
				case IDC_B_START_3: t_id = IDC_EDIT_START_3; break;
				case IDC_B_START_4: t_id = IDC_EDIT_START_4; break;
			};
			((CEdit*)GetDlgItem(t_id))->GetWindowText(temp_str, sizeof(temp_str));
			timers[gr].start = atol(temp_str);
			sprintf(temp_str, "%d", timers[gr].start);
			((CEdit*)GetDlgItem(t_id))->SetWindowText(temp_str);
			break;

		case IDC_B_STOP_1:
		case IDC_B_STOP_2:
		case IDC_B_STOP_3:
		case IDC_B_STOP_4:
			timers[gr].running = 0;
			break;
	};

	ReleaseMutex(timers_lock);

	return TRUE;
};

BOOL CEquipe_timer_testerDlg::TimerEnableDisable(int id) 
{
	int gr = 0;

	if ( (-1) == (gr = find_group_id(id)) )
		return TRUE;

	CButton* b = (CButton*)GetDlgItem(id);

	/* check status */
	if (((CButton*)GetDlgItem(id))->GetCheck())
	{
		/* enable group */
		memset(&timers[gr], 0, sizeof(struct timers_description));
		timers[gr].enabled = 1;
		
	}
	else
	{
		/* disable group */
		memset(&timers[gr], 0, sizeof(struct timers_description));
	};


	return TRUE;
}

void CEquipe_timer_testerDlg::ui_update(CCmdUI *pCmdUI)
{
	int id = pCmdUI->m_nID;
	int gr;

	/* check id present */
	if ( (-1) == (gr = find_group_id(id)) ) return;

	switch(pCmdUI->m_nID)
	{
		/* text feield displaying current value */
		case IDC_CURRENT_1:
		case IDC_CURRENT_2:
		case IDC_CURRENT_3:
		case IDC_CURRENT_4:
			pCmdUI->Enable( timers[gr].enabled  );
			char temp[1024];
			sprintf(temp, "%6.6d.%3.3d", timers[gr].data/1000, timers[gr].data % 1000);
			pCmdUI->SetText(temp);
			break;

		case IDC_B_RESET_1:
		case IDC_B_RESET_2:
		case IDC_B_RESET_3:
		case IDC_B_RESET_4:
			pCmdUI->Enable( timers[gr].enabled  );
			break;

		case IDC_RADIO_UP_1:
		case IDC_RADIO_UP_2:
		case IDC_RADIO_UP_3:
		case IDC_RADIO_UP_4:
			pCmdUI->Enable( (timers[gr].enabled) && (!(timers[gr].running)));
			pCmdUI->SetCheck ( !(timers[gr].countdown) );
			break;

		case IDC_RADIO_DOWN_1:
		case IDC_RADIO_DOWN_3:
		case IDC_RADIO_DOWN_2:
		case IDC_RADIO_DOWN_4:
			pCmdUI->Enable( (timers[gr].enabled) && (!(timers[gr].running)));
			pCmdUI->SetCheck ( (timers[gr].countdown) );
			break;

		case IDC_EDIT_START_1:
		case IDC_B_START_1:
		case IDC_EDIT_START_2:
		case IDC_B_START_2:
		case IDC_EDIT_START_3:
		case IDC_B_START_3:
		case IDC_EDIT_START_4:
		case IDC_B_START_4:
		case IDC_B_CONT_1:
		case IDC_B_CONT_2:
		case IDC_B_CONT_3:
		case IDC_B_CONT_4:
			pCmdUI->Enable( (timers[gr].enabled) && (!(timers[gr].running)));
			break;

		case IDC_B_STOP_1:
		case IDC_B_STOP_2:
		case IDC_B_STOP_3:
		case IDC_B_STOP_4:
			pCmdUI->Enable( (timers[gr].enabled) && ((timers[gr].running)));
			break;

	};

}

//dlg->UpdateDialogControls(dlg, false);


BOOL CEquipe_timer_testerDlg::PreTranslateMessage(MSG* pMsg) 
{
	UpdateDialogControls(this, false);
	return CDialog::PreTranslateMessage(pMsg);
}

LRESULT CEquipe_timer_testerDlg::OnKickIdle(WPARAM wParam, LPARAM lParam)
{
	UpdateDialogControls(this, FALSE);
	return 0;
}

void CEquipe_timer_testerDlg::OnTimer(UINT nIDEvent) 
{
	UpdateDialogControls(this, FALSE);
	CDialog::OnTimer(nIDEvent);
}
