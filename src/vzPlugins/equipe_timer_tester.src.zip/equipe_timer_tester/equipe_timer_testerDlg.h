// equipe_timer_testerDlg.h : header file
//

#if !defined(AFX_EQUIPE_TIMER_TESTERDLG_H__3635CF76_1493_434A_9666_D2EB42F66BA1__INCLUDED_)
#define AFX_EQUIPE_TIMER_TESTERDLG_H__3635CF76_1493_434A_9666_D2EB42F66BA1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CEquipe_timer_testerDlg dialog

class CEquipe_timer_testerDlg : public CDialog
{
// Construction
public:
	CEquipe_timer_testerDlg(CWnd* pParent = NULL);	// standard constructor
	char* serial_port_name;

// Dialog Data
	//{{AFX_DATA(CEquipe_timer_testerDlg)
	enum { IDD = IDD_EQUIPE_TIMER_TESTER_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEquipe_timer_testerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CEquipe_timer_testerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	BOOL TimerEnableDisable(int);
	void ui_update(CCmdUI *pCmdUI);
	BOOL CommandsProcess(int id);

	// ui updates
	BOOL PreTranslateMessage(MSG* pMsg);
	LRESULT OnKickIdle(WPARAM wParam, LPARAM lParam);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EQUIPE_TIMER_TESTERDLG_H__3635CF76_1493_434A_9666_D2EB42F66BA1__INCLUDED_)
