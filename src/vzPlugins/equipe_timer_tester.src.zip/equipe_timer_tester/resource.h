//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by equipe_timer_tester.rc
//
#define IDD_EQUIPE_TIMER_TESTER_DIALOG  102
#define IDR_MAINFRAME                   128
#define IDC_B_START_1                   1000
#define IDC_B_CONT_1                    1001
#define IDC_RADIO_UP_1                  1002
#define IDC_B_STOP_1                    1003
#define IDC_B_RESET_1                   1004
#define IDC_RADIO_DOWN_1                1005
#define IDC_EDIT_START_1                1006
#define IDC_CURRENT_1                   1007
#define IDC_B_START_2                   1008
#define IDC_B_CONT_2                    1009
#define IDC_B_STOP_2                    1010
#define IDC_B_RESET_2                   1011
#define IDC_RADIO_UP_2                  1012
#define IDC_RADIO_DOWN_2                1013
#define IDC_EDIT_START_2                1014
#define IDC_CURRENT_2                   1015
#define IDC_B_START_3                   1016
#define IDC_B_CONT_3                    1017
#define IDC_B_STOP_3                    1018
#define IDC_B_RESET_3                   1019
#define IDC_RADIO_UP_3                  1020
#define IDC_RADIO_DOWN_3                1021
#define IDC_EDIT_START_3                1022
#define IDC_CURRENT_3                   1023
#define IDC_B_START_4                   1024
#define IDC_B_CONT_4                    1025
#define IDC_B_STOP_4                    1026
#define IDC_B_RESET_4                   1027
#define IDC_RADIO_UP_4                  1028
#define IDC_RADIO_DOWN_4                1029
#define IDC_EDIT_START_4                1030
#define IDC_CURRENT_4                   1031
#define IDC_ENABLE_1                    1032
#define IDC_ENABLE_2                    1034
#define IDC_ENABLE_3                    1035
#define IDC_ENABLE_4                    1036

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
